<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1>Bienvenue, Vous êtes connecté.</h1>

<?php
echo "<pre>";
echo print_r($this->session->all_userdata());
echo "</pre>";
?>

<a href='<?php echo base_url() . "index.php/Connexion/deconnexion"; ?>'>Déconnexion</a>

</body>
</html>