<!DOCTYPE html>
<html>
<head>
    <title>Page Invalide</title>
</head>
<body>
<h1>Connexion échouée</h1>

<a href='<?php echo base_url()."Connexion/chargerVue"; ?>'>Réessayer</a>

</body>
</html>